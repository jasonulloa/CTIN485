using UnityEngine;
using System.Collections;

public class CreateGridLevel : MonoBehaviour
{
	GameObject block;
	GameObject holdThem;

	void Start ()
	{
		holdThem = GameObject.Find ("HoldThem");
	
		float x = 0;
		float y = 0;
		float z = 0;
		for (int i=0; i<10; i++) {
			for (int j=0; j<10; j++) {
				block = (GameObject)Instantiate (Resources.Load ("block"));
				block.transform.position = new Vector3 (x, y, z);
				x += block.transform.localScale.x;
				block.transform.parent = holdThem.transform;
			}
			x = 0;
			y += block.transform.localScale.y;
		}
	}
}


