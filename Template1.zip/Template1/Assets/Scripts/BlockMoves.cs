using UnityEngine;
using System.Collections;

public class BlockMoves : MonoBehaviour
{
	float zMove;

	void Start ()
	{
		float ranges = 100;
		zMove = Random.Range (-ranges, ranges) * 0.001f;
	}

	void Update ()	
	{
		transform.Translate (0, 0, zMove);
	}
}
